package com.lypeer.ipcserver.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;

import com.lypeer.ipcserver.Stub;

/**
 * Created by lypeer on 16-7-23.
 */
public class BinderService extends Service {

    private static Stub stub = new Stub() {
        @Override
        public String chat(String message) {
            return "成功连接服务端，我现在在服务端向你发出信息";
        }
    };

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return stub;
    }
}
