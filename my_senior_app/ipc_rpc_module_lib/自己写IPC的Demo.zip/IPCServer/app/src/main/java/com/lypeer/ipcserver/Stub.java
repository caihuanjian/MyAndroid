package com.lypeer.ipcserver;

import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.text.TextUtils;

/**
 * Created by lypeer on 16-7-23.
 */
public abstract class Stub extends Binder {

    private static final int CHAT = 0;

    public abstract String chat(String message);

    @Override
    protected boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
        switch (code) {
            case CHAT:
                String dataString = "";
                String replyString = "";
                if(0 != data.readInt()){
                    dataString = data.readString();
                }
                replyString = chat(dataString);
                reply.writeNoException();
                if(TextUtils.isEmpty(replyString)){
                    reply.writeInt(0);
                }else {
                    reply.writeInt(1);
                    reply.writeString(replyString);
                }
                return true;
            default:
                return super.onTransact(code, data, reply, flags);
        }
    }
}
