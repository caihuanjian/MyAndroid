package com.lypeer.ipcclient;

import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.text.TextUtils;

/**
 * Created by lypeer on 16-7-23.
 */
public class Proxy {

    private static final int CHAT = 0;

    private static IBinder mRemote;
    private static Proxy mInstance = new Proxy();

    private Proxy() {
    }

    public static Proxy getRemoteProxy(IBinder service) {
        mRemote = service;
        return mInstance;
    }

    public String chat(String message) {
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        try {
            if (TextUtils.isEmpty(message)) {
                data.writeInt(1);
                data.writeString(message);
            } else {
                data.writeInt(0);
            }
            mRemote.transact(CHAT, data, reply, 0);
            reply.readException();
            if(0 != reply.readInt()){
                return reply.readString();
            }
        } catch (RemoteException e) {
            e.printStackTrace();
        }finally {
            data.recycle();
            reply.recycle();
        }
        return "";
    }
}
