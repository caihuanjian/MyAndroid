package com.dl7.recycler.listener;

/**
 * Created by long on 2016/7/13.
 * 数据请求监听
 */
public interface OnRequestDataListener {
    /**
     * 加载更多
     */
    void onLoadMore();
}
