package com.dl7.mvp.module.photo.main;

/**
 * Created by long on 2016/9/5.
 * 图片界面接口
 */
public interface IPhotoMainView {

    /**
     * 更新数据
     * @param lovedCount 收藏数
     */
    void updateCount(int lovedCount);
}
