package com.king.tv.di.scope;

import javax.inject.Scope;

/**
 * @author Jenly <a href="mailto:jenly1314@gmail.com">Jenly</a>
 * @since 2017/3/3
 */

@Scope
public @interface FragmentScope {

}
